﻿(function () {
    angular.module("realestateApp", ["ngMessages"]);
}());